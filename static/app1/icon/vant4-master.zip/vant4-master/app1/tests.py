import hashlib
from django.test import TestCase
import requests

from app1 import dome_host, APPID, SECRET


# Create your tests here.


# 公众号使用AppID和AppSecret调用本接口来获取access_token
def get_wx_token():
    response = requests.get(
        f'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={APPID}&secret={SECRET}')
    return response.json()


# 请求获得jsapi_ticket
def get_jsapi_ticket():
    ACCESS_TOKEN = get_wx_token()['access_token']
    ticket = \
        requests.get(
            f'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token={ACCESS_TOKEN}&type=jsapi').json()
    return ticket['ticket']


# 微信签名生成
def generate_signature(noncestr, timestamp, state):
    # 将参数按照字段名的ASCII码从小到大排序
    try:
        params = {
            'noncestr': noncestr,
            'jsapi_ticket': get_jsapi_ticket(),
            'timestamp': timestamp,
            'url': 'http://' + dome_host + '/user_index/' + '?state=' + state,
        }
    except Exception as e:
        print(e)
        params = {
            'noncestr': noncestr,
            'jsapi_ticket': get_jsapi_ticket(),
            'timestamp': timestamp,
            'url': 'http://' + dome_host + '/user_index/',
        }
    sorted_params = sorted(params.items(), key=lambda x: x[0])

    # 拼接成字符串string1
    string1 = '&'.join([f"{key}={value}" for key, value in sorted_params])

    # 计算SHA1签名
    sha1 = hashlib.sha1()
    sha1.update(string1.encode('utf-8'))
    signature = sha1.hexdigest()

    return signature


#时间格式转化
def time_format(data):
    from datetime import datetime

    date_string = data

    # 删除时区信息
    date_string = date_string.replace(' GMT+0800 (中国标准时间)', '')

    # 定义月份的映射关系
    month_map = {
        'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
        'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12
    }

    # 解析日期字符串
    parts = date_string.split(' ')
    weekday = parts[0]
    month = month_map[parts[1]]
    day = int(parts[2])
    year = int(parts[3])
    time = parts[4]

    # 解析时间部分
    hour, minute, second = map(int, time.split(':'))

    # 构建datetime对象
    date_object = datetime(year, month, day, hour, minute, second)
    return date_object