from app1.setting import reade

data = reade('config.yaml')
APPID = data['appid_rule']  # 微信公众号appid
SECRET = data['secret_rule']  # 微信微信公众号SECRET
key = data['gaode_web_key_rule']  # 在高德地图开放平台申请的 API Key
dome_host = data['dome_host_rule']  # 域名（微信回调，如：baidu.com）
wx_wenjian = 'MP_verify_ccEO1TvkoA3UEOEr.txt'  # 微信服务验证文件
mo_ban_id = data['mo_ban_id_rule']  # 会议通知模板id
site_title = data['site_title_rule']  # 管理站点标题
