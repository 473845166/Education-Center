# -*- coding: utf-8 -*-
from datetime import datetime

from django.contrib import admin
from django.http import JsonResponse
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from simpleui.admin import AjaxAdmin
from app1 import site_title
from app1.models import CustomUser, TrainingCourse, Attendance, Feedback
from app1.tests import time_format
from app1.views2 import mo_ban_seed

try:

    admin.site.site_header = site_title
    admin.site.site_title = site_title

except Exception as e:
    admin.site.site_header = e
    admin.site.site_title = e


# Register your models here.

@admin.register(CustomUser)
class CustomUserAdmin(AjaxAdmin):
    actions = ['seed_info']

    @admin.action(description='发送通知')
    def seed_info(self, request, queryset):
        # 这里的queryset 会有数据过滤，只包含选中的数据

        post = request.POST
        # 这里获取到数据后，可以做些业务处理
        # post中的_action 是方法名
        # post中 _selected 是选中的数据，逗号分割
        if not post.get('_selected'):
            return JsonResponse(data={
                'status': 'error',
                'msg': '请先选中数据！'
            })
        else:
            try:
                user = request.user.info2['name']
            except:
                user = request.user
            string_time = time_format(request.POST['times'])
            mo_ban_seed(request, request.POST['name'], string_time, request.POST['address'],
                        request.POST['jie_shao'], user=user, _selected=request.POST['_selected'])
            return JsonResponse(data={
                'status': 'success',
                'msg': '处理成功！'
            })
    seed_info.layer = {
        'title': '发送通知',
        # 提示信息
        'tips': '推送微信模板',
        # 确认按钮显示文本
        'confirm_button': '确认提交',
        # 取消按钮显示文本
        'cancel_button': '取消',

        # 弹出层对话框的宽度，默认50%
        'width': '80%',

        # 表单中 label的宽度，对应element-ui的 label-width，默认80px
        'labelWidth': "80px",
        'params': [
            {
                # 这里的type 对应el-input的原生input属性，默认为input
                'type': 'input',
                # key 对应post参数中的key
                'key': 'name',
                # 显示的文本
                'label': '会议名称',
                # 为空校验，默认为False
                'require': True,
                'width': '200px'
            },
            {
                # 这里的type 对应el-input的原生input属性，默认为input
                'type': 'datetime',
                # key 对应post参数中的key
                'key': 'times',
                # 显示的文本
                'label': '时间',
                # 为空校验，默认为False
                'require': True
            },
            {
                # 这里的type 对应el-input的原生input属性，默认为input
                'type': 'input',
                # key 对应post参数中的key
                'key': 'address',
                # 显示的文本
                'label': '地点',
                # 为空校验，默认为False
                'require': True
            },
            {
                # 这里的type 对应el-input的原生input属性，默认为input
                'type': 'input',
                # key 对应post参数中的key
                'key': 'jie_shao',
                # 显示的文本
                'label': '介绍',
                # 为空校验，默认为False
                'require': False
            },
        ]
    }
    seed_info.type = 'success'

    list_display = ['id', 'name', 'connect', 'unit', 'photo', 'wx_name']

    @admin.display(description='真实姓名', ordering='id')
    def name(self, obj):
        if obj.info2 is None:
            return mark_safe(obj.username)
        return mark_safe(obj.info2['name'])

    @admin.display(description='联系方式', ordering='id')
    def connect(self, obj):
        if obj.info2 is None:
            return mark_safe('')
        return mark_safe(obj.info2['connect'])

    @admin.display(description='单位', ordering='id')
    def unit(self, obj):
        if obj.info2 is None:
            return mark_safe('')
        return mark_safe(obj.info2['unit'])

    @admin.display(description='微信昵称', ordering='id')
    def wx_name(self, obj):
        if obj.info1 is None:
            return mark_safe('')
        return mark_safe(obj.info1['nickname'])

    @admin.display(description='头像', ordering='id')
    def photo(self, obj):
        if obj.info1 is None:
            return mark_safe('')
        div = f"<img src='{obj.info1['headimgurl']}' width='50px'>"
        return mark_safe(div)


@admin.register(TrainingCourse)
class TrainingCourseAdmin(admin.ModelAdmin):
    list_display = [i.name for i in TrainingCourse._meta.fields if i.name != 'random_string'] + ['qr']

    @admin.display(description='二维码', ordering='id')
    def qr(self, obj):
        if obj.random_string is None:
            return format_html('')
        button = f"""<div onclick="window.open('/qr/?pk={obj.id}')"
                                    class="el-button el-button--warning el-button--small">查看二维码</div>""" + f"""
                                    <a href="/qr/?pk={obj.id}&d=1"><svg t="1687431399165" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2933" width="32" height="32"><path d="M502.010485 765.939573c3.773953 3.719718 8.686846 5.573949 13.596669 5.573949 0.075725 0 0.151449-0.010233 0.227174-0.011256 0.329505 0.016373 0.654916 0.050142 0.988514 0.050142 0.706081 0 1.400906-0.042979 2.087545-0.116657 4.352121-0.366344 8.607028-2.190899 11.961426-5.496178l335.053985-330.166675c7.619538-7.509021 7.709589-19.773346 0.200568-27.393907s-19.774369-7.711636-27.39493-0.201591L536.193005 706.304358 536.193005 50.019207c0-10.698666-8.67252-19.371186-19.371186-19.371186s-19.371186 8.67252-19.371186 19.371186l0 657.032164-306.881342-302.44838c-7.618515-7.509021-19.883863-7.419993-27.393907 0.199545-7.509021 7.619538-7.419993 19.884886 0.199545 27.393907L502.010485 765.939573z" fill="#FF9000" p-id="2934"></path><path d="M867.170139 711.020776c-10.698666 0-19.371186 8.67252-19.371186 19.371186l0 165.419494c0 13.054317-10.620895 23.675212-23.676236 23.675212L205.182103 919.486668c-13.054317 0-23.676236-10.620895-23.676236-23.675212L181.505867 730.391962c0-10.698666-8.67252-19.371186-19.371186-19.371186s-19.371186 8.67252-19.371186 19.371186l0 165.419494c0 34.416857 28.000728 62.416562 62.417585 62.416562l618.941638 0c34.417881 0 62.417585-27.999704 62.417585-62.416562L886.540302 730.391962C886.541325 719.693296 877.868805 711.020776 867.170139 711.020776z" fill="#FF9000" p-id="2935"></path></svg></a>
                                    """
        return format_html(f'{button}')


@admin.register(Attendance)
class TrainingCourseAdmin(admin.ModelAdmin):
    list_display = [i.name for i in Attendance._meta.fields]


@admin.register(Feedback)
class TrainingCourseAdmin(admin.ModelAdmin):
    list_display = [i.name for i in Feedback._meta.fields]
