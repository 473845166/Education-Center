# -*- coding: utf-8 -*-
import io
import secrets
import time

import qrcode
import requests
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, JsonResponse, FileResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from app1 import APPID, SECRET, key, dome_host
from app1.models import CustomUser, TrainingCourse, Attendance, Feedback
from app1.tests import generate_signature


# Create your views here.

# 微信开放平台授权
# def wx_pingtai(request):
#     CODE = request.GET.get('code')
#     APPID = 'wx34e7cbb8fdbd2937'  # 填写APPID
#     SECRET = 'c26bbd8ea37d66cb97dc0bf63beef810'  # 填写SECRET
#     url = f'https://api.weixin.qq.com/sns/oauth2/access_token?appid={APPID}&secret={SECRET}&code={CODE}&grant_type' \
#           '=authorization_code'
#     res = requests.get(url)
#     print(res.json())
#     # 获取登录信息
#     ACCESS_TOKEN = res.json()['access_token']
#     OPENID = res.json()['openid']
#     info_url = f'https://api.weixin.qq.com/sns/userinfo?access_token={ACCESS_TOKEN}&openid={OPENID}'
#     info = requests.get(info_url)
#     # 保存info.json()微信用户信息
#     CustomUser.objects.create_user()
#     return HttpResponse("ok")


# 微信公众号授权
def wx(request):
    CODE = request.GET.get('code')
    code_url = f'https://api.weixin.qq.com/sns/oauth2/access_token?appid={APPID}&secret={SECRET}&code={CODE}&grant_type' \
               f'=authorization_code'
    response = requests.get(code_url).json()
    info_url = f'https://api.weixin.qq.com/sns/userinfo?' \
               f'access_token={response["access_token"]}&openid={response["openid"]}&lang=zh_CN'
    get_info = requests.get(info_url).json()
    get_info['nickname'] = get_info['nickname'].encode('iso-8859-1').decode('utf-8')
    try:
        user = CustomUser.objects.get(username=get_info['openid'])
    except Exception as e:
        print(e)
        user = CustomUser.objects.create_user(username=get_info['openid'], password=get_info['openid'], info1=get_info)
    login(request, user)
    if request.GET.get('state'):
        state = request.GET.get('state')
        return redirect(reverse('user_index') + f'?state={state}')
    return redirect(reverse('user_index'))


def up_wx(request):
    CODE = request.GET.get('code')
    code_url = f'https://api.weixin.qq.com/sns/oauth2/access_token?appid={APPID}&secret={SECRET}&code={CODE}&grant_type' \
               f'=authorization_code'
    response = requests.get(code_url).json()
    info_url = f'https://api.weixin.qq.com/sns/userinfo?' \
               f'access_token={response["access_token"]}&openid={response["openid"]}&lang=zh_CN'
    get_info = requests.get(info_url).json()
    get_info['nickname'] = get_info['nickname'].encode('iso-8859-1').decode('utf-8')
    CustomUser.objects.filter(username=get_info['openid']).update(info1=get_info)
    return redirect(reverse('user_center'))


# 获取位置
def gaode(request):
    if request.method == "POST":
        url = "https://restapi.amap.com/v3/geocode/regeo"
        params = {
            "key": key,
            "location": f"{eval(request.body)['longitude']},{eval(request.body)['latitude']}",
            # "batch": "true",
            # "radius":1000
        }
        response = requests.get(url, params=params)
        data = response.json()
        return JsonResponse({'code': '1', 'data': data['regeocode']['formatted_address']})
    else:
        return JsonResponse({'code': '0'})


# 登录页面
def user_login(request):
    if request.user.is_authenticated:
        return redirect(reverse('user_index'))  # 用户已登录，重定向到主页
    if request.method == "POST":
        if authenticate(**eval(request.body)):
            login(request, authenticate(**eval(request.body)))
            return JsonResponse({'code': '1'})
        else:
            return JsonResponse({'code': '0'})

    return render(request, 'user/login.html', {'appid': APPID, 'dome_host': dome_host})


# 用户主页
@login_required
def user_index(request):
    if request.method == "POST":
        try:
            course = TrainingCourse.objects.get(random_string=eval(request.body)['state'])
            wz = eval(request.body)['wz']
            try:
                Attendance.objects.get(user=request.user, course=course)
                return JsonResponse({'code': 1, 'info': '您已经签到过了'})
            except Exception as e:
                print(e)
                Attendance.objects.create(user=request.user, course=course, address=wz)
                return JsonResponse({'code': 1, 'info': '签到成功'})
        except Exception as e:
            print(e)
            return JsonResponse({'code': 0, 'info': '请扫码检查信息后再签到'})
    # 新用户需要填写信息。如果已经绑定则直接提示相关信息
    if not request.user.is_superuser:
        if CustomUser.objects.get(id=request.user.id).info2 is None:
            if request.method == "PUT":
                CustomUser.objects.filter(id=request.user.id).update(info2=eval(request.body))
                return JsonResponse({'code': 1})
            return render(request, 'user/up_data.html', {})
    else:
        state = request.GET.get('state')
        try:
            course = TrainingCourse.objects.get(random_string=state).name
        except Exception as e:
            print(e)
            course = '请扫码签到'
        return render(request, 'user/index.html',
                      {'appId': APPID, 'course': course})
    noncestr = secrets.token_hex(16)
    timestamp = str(int(time.time()))
    state = request.GET.get('state')
    try:
        signature = generate_signature(noncestr, timestamp, state)
    except Exception as e:
        print(e)
        signature = None
    try:
        course = TrainingCourse.objects.get(random_string=state).name
    except Exception as e:
        print(e)
        course = '请扫码签到'
    return render(request, 'user/index.html',
                  {'appId': APPID, 'noncestr': noncestr, 'timestamp': timestamp, 'signature': signature,
                   'state': state, 'course': course})


# 签到记录
@login_required
def user_recode(request):
    if request.user.is_superuser:
        sl = Attendance.objects.all()
    else:
        sl = Attendance.objects.filter(user=request.user)
    data = []
    data.append({'check_in_time': '签到时间', 'course': '课程名称', 'status': '状态'})
    for i in sl:
        data.append({'check_in_time': i.check_in_time.strftime("%Y-%m-%d %H:%M:%S"), 'course': i.course.__str__(),
                     'status': '签到成功'})
    return render(request, 'user/index2.html', {'sl': data, 'num': len(sl) + 1})


# 个人中心
@login_required
def user_center(request):
    return render(request, 'user/index3.html', {'dome_host': dome_host, 'APPID': APPID})


# 退出
def logout_view(request):
    # 执行退出逻辑
    logout(request)
    # 其他逻辑或重定向
    return redirect(reverse('user_login'))


# 获取二维码
def qr(request):
    pk = request.GET.get('pk')
    random_string = TrainingCourse.objects.get(id=int(pk)).random_string

    url = f'https://open.weixin.qq.com/connect/oauth2/authorize?appid={APPID}&redirect_uri=http://{dome_host}' \
          f'/wx&response_type=code&scope=snsapi_userinfo&state={random_string}#wechat_redirect'

    # 生成二维码图像
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)
    image = qr.make_image(fill_color="black", back_color="white")
    # 将图像保存到内存中
    qr_stream = io.BytesIO()
    image.save(qr_stream)
    qr_stream.seek(0)
    if request.GET.get('d'):
        # 下载
        return FileResponse(qr_stream, as_attachment=True, filename='二维码.png')
    else:
        # 打开
        return FileResponse(qr_stream, filename='二维码.png')


def reply_seed(request):
    if request.method == 'POST':
        try:
            data = eval(request.body)
            info = data['title']
            if info is None:
                return JsonResponse({'code': 0, 'mgs': '请进入收到'})
            else:
                try:
                    Feedback.objects.get(info=info, user=request.user)
                    return JsonResponse({'code': 1, 'mgs': '已经收到过了'})
                except Exception as e:
                    print(e)
                    Feedback.objects.create(info=info, user=request.user)
                    return JsonResponse({'code': 1, 'mgs': '收到成功'})
        except Exception as e:
            data = eval(request.body)
            info = data['title']
            Feedback.objects.create(info=info, user=request.user)
            return JsonResponse({'code': 1, 'mgs': e})
    title = request.GET.get('name')
    user = request.GET.get('user')
    return render(request, 'pushlish/mo_ban_seed.html', {'title': title,'user':user})
