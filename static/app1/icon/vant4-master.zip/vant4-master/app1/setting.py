import yaml
from django.http import JsonResponse
from django.shortcuts import render
from django.contrib.auth.decorators import login_required


# 读取配置
def reade(filename):
    with open(filename, 'r', encoding='UTF-8') as f:
        data = yaml.safe_load(f)
        f.close()
        return data


# 保存配置
def write(filename, data):
    with open(filename, 'w', encoding='UTF-8') as f:
        yaml.dump(data, f, allow_unicode=True)
        f.close()


@login_required
def config1(request):
    if request.method == "POST":
        try:
            data = eval(request.body)
            if len(data['value']) > 0:
                res = {**reade('config.yaml')} if reade('config.yaml') is not None else {
                    **{f"{data['field']}": f"{data['value']}"}}
                res[data['field']] = data['value']
                write('config.yaml', res)
                code = 1
                mgs = f'保存成功'
            else:
                code = 0
                mgs = '请填写'
        except Exception as e:
            print(e)
            code = 0
            mgs = '请填写'
        return JsonResponse({'code': code, 'mgs': mgs})
    return render(request, 'setting/config1.html', {'data': reade('config.yaml')})
