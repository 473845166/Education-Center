# -*- coding: utf-8 -*-
import uuid

from django.db import models

# Create your models here.

from django.contrib.auth.models import AbstractUser


class CustomUser(AbstractUser):
    # 添加自定义字段
    info1_ping = models.JSONField(verbose_name='微信开放平台', blank=True, null=True)
    info1 = models.JSONField(verbose_name='微信公众号', blank=True, null=True)
    info2 = models.JSONField(verbose_name='备用', blank=True, null=True)

    def __str__(self):
        try:
            return self.info2['name']
        except Exception as e:
            print(e)
            return self.username


class TrainingCourse(models.Model):
    name = models.CharField(verbose_name="课程名称", max_length=100)
    description = models.TextField(verbose_name="课程描述")
    start_time = models.DateTimeField(verbose_name="开始时间")
    created_time = models.DateTimeField(verbose_name="创建时间", auto_now_add=True)
    random_string = models.CharField(max_length=100, default=uuid.uuid4, unique=True, editable=False)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "培训课程"
        verbose_name_plural = "培训课程"


class Attendance(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="用户")
    course = models.ForeignKey(TrainingCourse, on_delete=models.CASCADE, verbose_name="课程")
    check_in_time = models.DateTimeField(verbose_name="签到时间", auto_now_add=True)
    address = models.CharField(verbose_name="位置", max_length=255)

    def __str__(self):
        return f"{self.user.username} - {self.course.name}"

    class Meta:
        verbose_name = "签到记录"
        verbose_name_plural = "签到记录"


class Feedback(models.Model):
    info = models.CharField(verbose_name="通知名称", max_length=255)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="用户")
    check_in_time = models.DateTimeField(verbose_name="收到时间", auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.info}"

    class Meta:
        verbose_name = "收到记录"
        verbose_name_plural = "收到记录"
