import json

import requests
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect

from app1 import APPID, mo_ban_id, dome_host
from app1.models import CustomUser
from app1.tests import get_wx_token


# 微信模板消息
def post_xy(request):
    # 设置所属行业
    ACCESS_TOKEN = get_wx_token()['access_token']
    url = f'https://api.weixin.qq.com/cgi-bin/template/api_set_industry?access_token={ACCESS_TOKEN}'
    data = {
        "industry_id1": "1",
        "industry_id2": "4"
    }
    response = requests.post(url, data=json.dumps(data))
    return JsonResponse(response.json())


# 获取设置的行业信息
def post_xy_info(request):
    # 设置所属行业
    ACCESS_TOKEN = get_wx_token()['access_token']
    url = f'https://api.weixin.qq.com/cgi-bin/template/get_industry?access_token={ACCESS_TOKEN}'

    response = requests.get(url)
    return JsonResponse(response.json())


# 获得模板ID (微信公众号=》平台广告与服务=》模板消息)
def post_mo_ban_id(request):
    # 设置所属行业
    ACCESS_TOKEN = get_wx_token()['access_token']
    url = f'https://api.weixin.qq.com/cgi-bin/template/api_add_template?access_token={ACCESS_TOKEN}'
    data = {
        "template_id_short": "TM00210"
    }
    response = requests.post(url, data=json.dumps(data))
    return JsonResponse(response.json())


# 获取模板列表
def mo_ban_list(request):
    ACCESS_TOKEN = get_wx_token()['access_token']
    url = f'https://api.weixin.qq.com/cgi-bin/template/get_all_private_template?access_token={ACCESS_TOKEN}'
    response = requests.get(url)
    return response.json()


# 发送模板消息
def mo_ban_seed(request, name, times, address, jie_shao,**kwargs):
    ACCESS_TOKEN = get_wx_token()['access_token']
    template = {
        "first": {
            "value": '这是一条新通知',
            "color": "#173177"
        },
        "keyword1": {
            "value": f'{name}',
            "color": "#173177"
        },
        "keyword2": {
            "value": f'{times}',
            "color": "#173177"
        },
        "keyword3": {
            "value": f'{address}',
            "color": "#173177"
        },
        "keyword4": {
            "value": f'{jie_shao}',
            "color": "#173177"
        }
    }
    try:
        for i in eval(kwargs['_selected']):
            openid = CustomUser.objects.get(id=i).username
            data = {
                "touser": f'{openid}',
                "template_id": f"{mo_ban_id}",
                "url": f"http://{dome_host}/reply_seed/",
                "appid": f"{APPID}",
                "data": template
            }
            url = f'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token={ACCESS_TOKEN}'

            response = requests.post(url, data=json.dumps(data))
    except:
        openid = CustomUser.objects.get(id=kwargs['_selected']).username
        data = {
            "touser": f'{openid}',
            "template_id": f"{mo_ban_id}",
            "url": f"http://{dome_host}/reply_seed/?"+f"name={name}&user={kwargs['user']}",
            "appid": f"{APPID}",
            "data": template
        }
        url = f'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token={ACCESS_TOKEN}'

        response = requests.post(url, data=json.dumps(data))
