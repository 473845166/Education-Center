"""
URL configuration for djangoProject1 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.shortcuts import redirect
from django.urls import path, reverse
from django.views.generic import TemplateView
from app1 import views, wx_wenjian, views2, setting


urlpatterns = [
    path('admin/', admin.site.urls),
    # path('wx_pingtai/', views.wx_pingtai),
    path('wx/', views.wx,name='wx'),
    path('up_wx/', views.up_wx,name='up_wx'),
    path('MP_verify_ccEO1TvkoA3UEOEr.txt', TemplateView.as_view(template_name=f'{wx_wenjian}',content_type='text/plain')),
    path('user_login/',views.user_login,name='user_login'),
    path('user_index/', views.user_index, name='user_index'),
    path('',views.user_login),
    path('user_recode/', views.user_recode, name='user_recode'),
    path('user_center/', views.user_center, name='user_center'),
    path('logout/', views.logout_view, name='logout'),
    path('gaode/', views.gaode, name='gaode'),
    path('qr/', views.qr, name='qr'),
    path('post_xy/', views2.post_xy, name='post_xy'),
    path('post_xy_info/', views2.post_xy_info, name='post_xy_info'),
    path('post_mo_ban_id/', views2.post_mo_ban_id, name='post_mo_ban_id'),
    path('mo_ban_list/', views2.mo_ban_list, name='mo_ban_list'),
    path('mo_ban_seed/', views2.mo_ban_seed, name='mo_ban_seed'),
    path('config1/', admin.site.admin_view(setting.config1), name='config1'),
    path('reply_seed/', views.reply_seed, name='reply_seed'),
]
